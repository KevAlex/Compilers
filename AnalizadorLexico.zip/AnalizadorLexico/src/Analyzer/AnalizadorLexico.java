/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Analyzer;

import java.io.File;

/**
 *
 * @author estudiantes
 */
public class AnalizadorLexico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //String path =  "C:/Users/estudiantes/Documents/NetBeansProjects/AnalizadorLexico/src/Analyzer/Lexico.flex";
        //String path = "C:/Users/kevin/Documents/U. Distrital/Seventh Semester/Science 3/AnalizadorLexico/src/Analyzer/Lexico.flex";
        String path= "C:/Users/estudiantes/Pictures/Saved Pictures/AnalizadorLexico/src/Analyzer/Lexico.flex";
        generateLex(path);
        
        Formulario prueba = new Formulario();
        prueba.setVisible(true);
        prueba.setLocationRelativeTo(null);
        prueba.setDefaultCloseOperation(prueba.EXIT_ON_CLOSE);
        
    }
    
    public static void generateLex(String path){
        File arc = new File (path);
        JFlex.Main.generate(arc);
    }
}
