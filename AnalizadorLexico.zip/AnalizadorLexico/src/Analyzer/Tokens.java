/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Analyzer;

/**
 *
 * @author estudiantes
 */
public enum Tokens {
    
    /*
    
    */ 
    
    T_dato,
    Linea,
    Comillas ,
    ComiSimple,
     P_dato,
     Cadena,
     Break,
     Void,
     Null,
     Static,
     Sizeof,
     Default,
     Struct,
     Include,
     If,
     Else,
     Switch,
     Case,
     Do,
     While,
     For,
     Igual,
     Suma,
     Resta,
     Multiplicacion,
     Division,
     Op_logico,
     Op_relacional,
      Op_atribucion,
     Op_incremento,
     Op_booleano,
     Parentesis_a,
     Parentesis_c,
     Llave_a,
     Llave_c,
     Corchete_c,
     Main,
     P_coma,
     Puntos,
     Numeral,
     Identificador,
     Numero,
     Corchete_a,
     ERROR,
     Punt,
     Coma,
     
}
